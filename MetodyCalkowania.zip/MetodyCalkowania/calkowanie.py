"""
================================================================================
PROGRAM: Całkowanie Numeryczne - Analiza Porównawcza Metod
PRZEDMIOT: Metody Numeryczne / Obliczenia Naukowe (Praca w parach)
================================================================================

OPIS PROGRAMU:
Program służy do numerycznego wyznaczania wartości całki oznaczonej:
    I = ∫_{-2}^{3} |x^3 - 3x - 2| dx

DOKŁADNA WARTOŚĆ ANALITYCZNA:
    Wielomian pod modułem: w(x) = x^3 - 3x - 2 = (x + 1)^2 * (x - 2)
    Pierwiastki: x = -1 (dwukrotny, bez zmiany znaku), x = 2 (jednokrotny)
    Znak:
      - dla x ∈ [-2, 2]: w(x) <= 0  ==>  |w(x)| = -x^3 + 3x + 2
      - dla x ∈ [2, 3]:  w(x) >= 0  ==>  |w(x)| = x^3 - 3x - 2
    Całka analityczna:
      I = ∫_{-2}^{2} (-x^3 + 3x + 2) dx + ∫_{2}^{3} (x^3 - 3x - 2) dx
      I = 8 + 6.75 = 14.75 = 59/4

ZAIMPLEMENTOWANE METODY CAŁKOWANIA:
    1. Metoda prostokątów (z punktem lewym) - rząd zbieżności O(h)
    2. Metoda trapezów                      - rząd zbieżności O(h^2)
    3. Metoda Simpsona (parabol)            - rząd zbieżności O(h^4) (analitycznie ścisła dla w(x) st. 3)
    4. Metoda Monte Carlo (średniej wart.)  - zbieżność stochastyczna O(1/√n), stały seed = 42
    5. Metoda prostokątów (z pkt. środkowym)- rząd zbieżności O(h^2) [wariant uzupełniający]

BADANE WARTOŚCI PODPRZEDZIAŁÓW (KROKÓW):
    n ∈ {1000, 10000, 100000, 1000000}

Dla każdej metody i każdej wartości n program wyznacza:
    - wartość numeryczną całki (Inum)
    - błąd bezwzględny: |Inum - Idokladne|
    - błąd względny: (|Inum - Idokladne| / Idokladne) * 100%
    - czas wykonania w milisekundach (ms) z wysoką precyzją
================================================================================
"""

import sys
import time
import math
import random
import csv
from typing import Callable, Dict, List, Tuple, Any

# Konfiguracja kodowania UTF-8 dla konsoli Windows
if hasattr(sys.stdout, "reconfigure"):
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass
if hasattr(sys.stderr, "reconfigure"):
    try:
        sys.stderr.reconfigure(encoding="utf-8")
    except Exception:
        pass

# ==============================================================================
# 1. DEFINICJA FUNKCJI PODCAŁKOWEJ I WARTOŚCI ANALITYCZNEJ
# ==============================================================================

A: float = -2.0
B: float = 3.0
DOKLADNA_CALKA: float = 14.75  # 59 / 4


def f(x: float) -> float:
    """
    Funkcja podcałkowa f(x) = |x^3 - 3x - 2|.
    """
    return abs(x * x * x - 3.0 * x - 2.0)


def calka_analityczna() -> float:
    """
    Zwraca dokładną wartość analityczną całki: 59 / 4 = 14.75.
    """
    return DOKLADNA_CALKA


# ==============================================================================
# 2. ALGORYTMY CAŁKOWANIA NUMERYCZNEGO
# ==============================================================================

def metoda_prostokatow_lewa(funkcja: Callable[[float], float], a: float, b: float, n: int) -> float:
    """
    Kwadratura prostokątów z lewym punktem podziału.
    Wzór złożony:
        I_L = h * sum_{i=0}^{n-1} f(a + i*h)
        gdzie h = (b - a) / n
    Rząd zbieżności: O(h).
    """
    h = (b - a) / n
    suma = sum(funkcja(a + i * h) for i in range(n))
    return h * suma


def metoda_prostokatow_srodkowa(funkcja: Callable[[float], float], a: float, b: float, n: int) -> float:
    """
    Kwadratura prostokątów z punktem środkowym (Midpoint rule).
    Wzór złożony:
        I_M = h * sum_{i=0}^{n-1} f(a + (i + 0.5)*h)
    Rząd zbieżności: O(h^2).
    """
    h = (b - a) / n
    suma = sum(funkcja(a + (i + 0.5) * h) for i in range(n))
    return h * suma


def metoda_trapezow(funkcja: Callable[[float], float], a: float, b: float, n: int) -> float:
    """
    Złożona metoda trapezów.
    Wzór:
        I_T = h * [ (f(a) + f(b)) / 2 + sum_{i=1}^{n-1} f(a + i*h) ]
        gdzie h = (b - a) / n
    Rząd zbieżności: O(h^2).
    """
    h = (b - a) / n
    suma_wewnetrzna = sum(funkcja(a + i * h) for i in range(1, n))
    return h * (0.5 * (funkcja(a) + funkcja(b)) + suma_wewnetrzna)


def metoda_simpsona(funkcja: Callable[[float], float], a: float, b: float, n: int) -> float:
    """
    Złożona metoda Simpsona (parabol).
    Wymaga parzystej liczby podprzedziałów n.
    Wzór:
        I_S = (h / 3) * [ f(a) + 4 * sum_{i nieparzyste} f(x_i) + 2 * sum_{i parzyste} f(x_i) + f(b) ]
    Rząd zbieżności ogólny: O(h^4).
    Dla wielomianów stopnia <= 3 kwadratura jest analitycznie ścisła.
    """
    if n % 2 != 0:
        raise ValueError("Liczba podprzedziałów n w metodzie Simpsona musi być parzysta!")
    h = (b - a) / n
    suma_nieparzyste = sum(funkcja(a + i * h) for i in range(1, n, 2))
    suma_parzyste = sum(funkcja(a + i * h) for i in range(2, n, 2))
    return (h / 3.0) * (funkcja(a) + 4.0 * suma_nieparzyste + 2.0 * suma_parzyste + funkcja(b))


def metoda_monte_carlo(funkcja: Callable[[float], float], a: float, b: float, n: int, seed: int = 42) -> float:
    """
    Metoda Monte Carlo - wariant średniej wartości w punktach losowych (Mean Value Method).
    Wzór:
        I_MC = (b - a) * (1 / n) * sum_{i=1}^{n} f(X_i),  gdzie X_i ~ U(a, b)
    Stałe ziarno (seed = 42) gwarantuje 100% powtarzalność wyników.
    Rząd zbieżności stochastycznej: O(1 / sqrt(n)).
    """
    random.seed(seed)
    suma = sum(funkcja(random.uniform(a, b)) for _ in range(n))
    return (b - a) * (suma / n)


# Słownik metod głównych (4 wymagane + 1 uzupełniająca)
METODY_GLOWNE = [
    ("Metoda prostokątów (lewy punkt)", metoda_prostokatow_lewa),
    ("Metoda trapezów", metoda_trapezow),
    ("Metoda Simpsona (parabol)", metoda_simpsona),
    ("Metoda Monte Carlo (średnia wart.)", lambda f, a, b, n: metoda_monte_carlo(f, a, b, n, seed=42)),
]

METODY_WSZYSTKIE = [
    ("Metoda prostokątów (lewy punkt)", metoda_prostokatow_lewa),
    ("Metoda trapezów", metoda_trapezow),
    ("Metoda Simpsona (parabol)", metoda_simpsona),
    ("Metoda Monte Carlo (średnia wart.)", lambda f, a, b, n: metoda_monte_carlo(f, a, b, n, seed=42)),
    ("Metoda prostokątów (środkowy punkt)", metoda_prostokatow_srodkowa),
]


# ==============================================================================
# 3. MODUŁ EKSPERYMENTU OBLICZENIOWEGO I POMIARU CZASU
# ==============================================================================

def zmierz_metode(
    nazwa: str,
    funkcja_metody: Callable,
    a: float,
    b: float,
    n: int,
    liczba_powtorzen: int = 1
) -> Tuple[float, float]:
    """
    Mierzy czas wykonania metody w milisekundach oraz zwraca obliczoną wartość.
    Dla stabilności pomiaru przy małych n stosuje uśrednianie czasu z powtórzeń.
    """
    # Pierwszy przebieg wyznacza wartość całki
    wartosc = funkcja_metody(f, a, b, n)

    # Pomiar czasu
    t_start = time.perf_counter()
    for _ in range(liczba_powtorzen):
        _ = funkcja_metody(f, a, b, n)
    t_end = time.perf_counter()

    czas_ms = ((t_end - t_start) / liczba_powtorzen) * 1000.0
    return wartosc, czas_ms


def przeprowadz_badania(
    wartosci_n: List[int],
    metody: List[Tuple[str, Callable]] = METODY_WSZYSTKIE
) -> List[Dict[str, Any]]:
    """
    Przeprowadza pełną serię obliczeń dla wszystkich zdefiniowanych n oraz metod.
    Zwraca ustrukturyzowaną listę wyników.
    """
    dokladna = calka_analityczna()
    wyniki = []

    for n in wartosci_n:
        # Dobór liczby powtórzeń do precyzyjnego pomiaru czasu
        if n <= 1000:
            powtorzenia = 10
        elif n <= 10000:
            powtorzenia = 5
        elif n <= 100000:
            powtorzenia = 2
        else:
            powtorzenia = 1

        for nazwa, func in metody:
            wartosc, czas_ms = zmierz_metode(nazwa, func, A, B, n, liczba_powtorzen=powtorzenia)
            blad_bezwzgledny = abs(wartosc - dokladna)
            blad_wzgledny_proc = (blad_bezwzgledny / dokladna) * 100.0

            wyniki.append({
                "n": n,
                "metoda": nazwa,
                "wartosc": wartosc,
                "blad_bezwzgledny": blad_bezwzgledny,
                "blad_wzgledny_proc": blad_wzgledny_proc,
                "czas_ms": czas_ms,
            })

    return wyniki


# ==============================================================================
# 4. PREZENTACJA I FORMATOWANIE WYNIKÓW
# ==============================================================================

def drukuj_tabele_konsolowa(wyniki: List[Dict[str, Any]]) -> None:
    """
    Wyświetla estetycznie sformatowane tabele wyników w terminalu.
    """
    if hasattr(sys.stdout, "reconfigure"):
        try:
            sys.stdout.reconfigure(encoding="utf-8")
        except Exception:
            pass

    print("\n" + "=" * 108)
    print("                      POROWNANIE METOD CALKOWANIA NUMERYCZNEGO")
    print(f"        Calka: I = calka_{-2}^{3} |x^3 - 3x - 2| dx  |  Wartosc analityczna: I_dokladne = {DOKLADNA_CALKA:.6f}")
    print("=" * 108)

    wartosci_n = sorted(list(set(row["n"] for row in wyniki)))

    for n in wartosci_n:
        print(f"\n>>> Liczba podprzedzialow / prob: n = {n:,} (krok h = {5.0/n:.8f})")
        print("-" * 108)
        print(f"{'Metoda calkowania':<37} | {'Wartosc I_num':<16} | {'Blad bezwzgl.':<15} | {'Blad wzgl. [%]':<16} | {'Czas [ms]':<10}")
        print("-" * 108)

        wiersze_n = [r for r in wyniki if r["n"] == n]
        for r in wiersze_n:
            print(
                f"{r['metoda']:<37} | "
                f"{r['wartosc']:<16.10f} | "
                f"{r['blad_bezwzgledny']:<15.8e} | "
                f"{r['blad_wzgledny_proc']:<16.8f} | "
                f"{r['czas_ms']:<10.3f}"
            )
        print("-" * 108)


def zapisz_do_csv(wyniki: List[Dict[str, Any]], sciezka_csv: str = "wyniki_calkowania.csv") -> None:
    """
    Eksportuje wyniki obliczeń do pliku CSV.
    """
    naglowki = ["n", "metoda", "wartosc", "blad_bezwzgledny", "blad_wzgledny_proc", "czas_ms"]
    with open(sciezka_csv, mode="w", newline="", encoding="utf-8") as plik:
        writer = csv.DictWriter(plik, fieldnames=naglowki)
        writer.writeheader()
        for r in wyniki:
            writer.writerow(r)
    print(f"\n[OK] Wyniki pomyślnie wyeksportowano do pliku CSV: {sciezka_csv}")


# ==============================================================================
# 5. GENEROWANIE WYKRESÓW NAUKOWYCH (MATPLOTLIB)
# ==============================================================================

def generuj_wykresy(wyniki: List[Dict[str, Any]]) -> None:
    """
    Generuje profesjonalne wykresy do sprawozdania:
      1. Przebieg funkcji całkowanej z obszarem całkowania (wykres_funkcji.png)
      2. Zbieżność błędów w skali logarytmicznej (wykres_bledow.png)
      3. Zależność czasu obliczeń od liczby podprzedziałów n (wykres_czasow.png)
    """
    try:
        import matplotlib
        import matplotlib.pyplot as plt
        import numpy as np
    except ImportError:
        print("[OSTRZEŻENIE] Brak biblioteki matplotlib/numpy. Pomijanie generowania wykresów.")
        return

    plt.style.use("seaborn-v0_8-whitegrid" if "seaborn-v0_8-whitegrid" in plt.style.available else "default")
    matplotlib.rcParams["font.sans-serif"] = "DejaVu Sans, Arial, Helvetica"
    matplotlib.rcParams["axes.edgecolor"] = "#cccccc"
    matplotlib.rcParams["axes.linewidth"] = 0.8

    # --- WYKRES 1: Funkcja podcałkowa ---
    fig, ax = plt.subplots(figsize=(9, 5.2), dpi=300)
    x = np.linspace(-2.3, 3.3, 1000)
    w = x**3 - 3.0 * x - 2.0
    f_val = np.abs(w)

    ax.plot(x, f_val, color="#1f77b4", lw=2.4, label=r"$f(x) = |x^3 - 3x - 2|$")
    ax.plot(x, w, color="#888888", ls="--", lw=1.2, alpha=0.6, label=r"$w(x) = x^3 - 3x - 2$ (bez modułu)")

    # Obszary całkowania
    x1 = np.linspace(-2.0, 2.0, 400)
    ax.fill_between(x1, np.abs(x1**3 - 3.0*x1 - 2.0), color="#2ca02c", alpha=0.35, label=r"Obszar $I_1 \in [-2, 2]$ ($Pole = 8.00$)")

    x2 = np.linspace(2.0, 3.0, 300)
    ax.fill_between(x2, np.abs(x2**3 - 3.0*x2 - 2.0), color="#ff7f0e", alpha=0.35, label=r"Obszar $I_2 \in [2, 3]$ ($Pole = 6.75$)")

    # Punkty kluczowe
    ax.scatter([-1.0, 2.0], [0.0, 0.0], color="#d62728", s=65, zorder=5)
    ax.annotate("x = -1 (pierwiastek podwójny, min)", xy=(-1.0, 0.0), xytext=(-2.1, 4.0),
                arrowprops=dict(facecolor="#333333", shrink=0.08, width=1.0, headwidth=5),
                fontsize=9.5, fontweight="bold", bbox=dict(boxstyle="round,pad=0.3", fc="white", ec="#cccccc", lw=0.8))
    ax.annotate("x = 2 (punkt załamania modułu)", xy=(2.0, 0.0), xytext=(0.4, 9.5),
                arrowprops=dict(facecolor="#333333", shrink=0.08, width=1.0, headwidth=5),
                fontsize=9.5, fontweight="bold", bbox=dict(boxstyle="round,pad=0.3", fc="white", ec="#cccccc", lw=0.8))

    ax.axvline(-2.0, color="#666666", ls=":", alpha=0.7)
    ax.axvline(3.0, color="#666666", ls=":", alpha=0.7)
    ax.set_title(r"Wykres funkcji podcałkowej $f(x) = |x^3 - 3x - 2|$ na przedziale $[-2, 3]$", fontsize=13, fontweight="bold", pad=12)
    ax.set_xlabel("x", fontsize=11)
    ax.set_ylabel("f(x)", fontsize=11)
    ax.set_ylim(-5.0, 18.0)
    ax.set_xlim(-2.3, 3.3)
    ax.legend(loc="upper left", frameon=True, facecolor="white", framealpha=0.92, fontsize=10)
    plt.tight_layout()
    plt.savefig("wykres_funkcji.png")
    plt.close()
    print("[OK] Wygenerowano wykres funkcji: wykres_funkcji.png")

    # --- WYKRES 2: Zbieżność błędów (log-log) ---
    fig, ax = plt.subplots(figsize=(9, 5.5), dpi=300)
    kolory = {
        "Metoda prostokątów (lewy punkt)": "#1f77b4",
        "Metoda trapezów": "#2ca02c",
        "Metoda Simpsona (parabol)": "#d62728",
        "Metoda Monte Carlo (średnia wart.)": "#9467bd",
        "Metoda prostokątów (środkowy punkt)": "#ff7f0e",
    }
    markery = {
        "Metoda prostokątów (lewy punkt)": "o",
        "Metoda trapezów": "s",
        "Metoda Simpsona (parabol)": "D",
        "Metoda Monte Carlo (średnia wart.)": "^",
        "Metoda prostokątów (środkowy punkt)": "v",
    }

    wszystkie_metody = list(dict.fromkeys(r["metoda"] for r in wyniki))
    for m in wszystkie_metody:
        rekordy = [r for r in wyniki if r["metoda"] == m]
        xs = [r["n"] for r in rekordy]
        # Zabezpieczenie przed 0 przy logarytmowaniu dla Simpsona
        ys = [max(r["blad_bezwzgledny"], 1e-16) for r in rekordy]
        ax.plot(
            xs, ys,
            label=m,
            color=kolory.get(m, "#333333"),
            marker=markery.get(m, "o"),
            lw=2.0,
            markersize=7,
        )

    ax.set_xscale("log")
    ax.set_yscale("log")
    ax.set_title("Zbieżność metod całkowania numerycznego (błąd bezwzględny vs n)", fontsize=13, fontweight="bold", pad=12)
    ax.set_xlabel("Liczba podprzedziałów / prób losowych (n)", fontsize=11)
    ax.set_ylabel("Błąd bezwzględny |I_num - I_dokładne|", fontsize=11)
    ax.grid(True, which="both", ls="--", alpha=0.5)
    ax.legend(loc="lower left", frameon=True, facecolor="white", framealpha=0.92, fontsize=9.5)
    plt.tight_layout()
    plt.savefig("wykres_bledow.png")
    plt.close()
    print("[OK] Wygenerowano wykres błędów: wykres_bledow.png")

    # --- WYKRES 3: Czasy obliczeń ---
    fig, ax = plt.subplots(figsize=(9, 5.2), dpi=300)
    for m in wszystkie_metody:
        rekordy = [r for r in wyniki if r["metoda"] == m]
        xs = [r["n"] for r in rekordy]
        ys = [r["czas_ms"] for r in rekordy]
        ax.plot(
            xs, ys,
            label=m,
            color=kolory.get(m, "#333333"),
            marker=markery.get(m, "o"),
            lw=2.0,
            markersize=7,
        )

    ax.set_xscale("log")
    ax.set_yscale("log")
    ax.set_title("Wydajność czasowa metod całkowania w zależności od n", fontsize=13, fontweight="bold", pad=12)
    ax.set_xlabel("Liczba podprzedziałów / prób losowych (n)", fontsize=11)
    ax.set_ylabel("Czas wykonania [ms] (skala logarytmiczna)", fontsize=11)
    ax.grid(True, which="both", ls="--", alpha=0.5)
    ax.legend(loc="upper left", frameon=True, facecolor="white", framealpha=0.92, fontsize=9.5)
    plt.tight_layout()
    plt.savefig("wykres_czasow.png")
    plt.close()
    print("[OK] Wygenerowano wykres czasów: wykres_czasow.png")


# ==============================================================================
# 6. GŁÓWNA FUNKCJA WYKONAWCZA
# ==============================================================================

def main() -> None:
    """
    Główny punkt wejścia do programu.
    """
    n_doswiadczenie = [1000, 10000, 100000, 1000000]

    print("\n" + "=" * 80)
    print("  ROZPOCZĘCIE EKSPERYMENTU CAŁKOWANIA NUMERYCZNEGO")
    print(f"  Zakres całkowania: [{A}, {B}], Dokładna całka: {DOKLADNA_CALKA}")
    print(f"  Wartości n: {n_doswiadczenie}")
    print("=" * 80)

    # 1. Wykonanie obliczeń
    wyniki = przeprowadz_badania(n_doswiadczenie, METODY_WSZYSTKIE)

    # 2. Wyświetlenie tabel w konsoli
    drukuj_tabele_konsolowa(wyniki)

    # 3. Zapis do CSV
    zapisz_do_csv(wyniki, "wyniki_calkowania.csv")

    # 4. Generowanie wykresów
    generuj_wykresy(wyniki)

    print("\n" + "=" * 80)
    print("  ZAKOŃCZONO POMYŚLNIE EKSPERYMENT.")
    print("=" * 80 + "\n")


if __name__ == "__main__":
    main()
